package asteroids;

import java.awt.event.*;
import java.io.BufferedInputStream;
import java.io.IOException;
import java.util.Iterator;

import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.*;

import asteroids.participants.AlienShip;
import asteroids.participants.Asteroid;
import asteroids.participants.Bullet;
import asteroids.participants.Ship;
import static asteroids.Constants.*;

/**
 * Controls a game of Asteroids.
 */
public class Controller implements KeyListener, ActionListener {
	// The state of all the Participants
	private ParticipantState pstate;
	private AlienShip AlienShip;
	// The ship (if one is active) or null (otherwise)
	private Ship ship;
	// There boolean is about to control the go up, go left, go right
	// and make them smooth.
	private boolean keyPressL = false;
	private boolean keyPressR = false;
	private boolean keyPressS = false;
	// When this timer goes off, it is time to refresh the animation
	private Timer refreshTimer;
	// This boolean controls the size of the alien, when the alien appears.
	private boolean pickAlienShip;

	// The time at which a transition to a new stage of the game should be made.
	// A transition is scheduled a few seconds in the future to give the user
	// time to see what has happened before doing something like going to a new
	// level or resetting the current level.
	private long transitionTime;

	// Number of lives left
	private int lives;
	// The game display
	private Display display;
	// Score of game
	private int score;
	// level of game
	private int level;
	// Sound of game
	private Clip bangAlienShip;
	private Clip bangLarge;
	private Clip bangMedium;
	private Clip bangShip;
	private Clip bangSmall;
	private Clip fire;
	private Clip saucerBig;
	private Clip saucerSmall;
	private Clip thrust;

	/**
	 * Constructs a controller to coordinate the game and screen
	 */
	public Controller() {
		// Record the game and screen objects
		display = new Display(this);
		display.setVisible(true);

		// Initialize the ParticipantState
		pstate = new ParticipantState();

		// Set up the refresh timer.
		refreshTimer = new Timer(FRAME_INTERVAL, this);

		// Clear the transitionTime
		transitionTime = Long.MAX_VALUE;

		// Bring up the splash screen and start the refresh timer
		splashScreen();
		refreshTimer.start();
		// This level right here will control when level + 1, asteroids + 1
		// which makes
		// the number of asteroids connects to level
		level = 1;
		// Sound
		bangAlienShip = createClip("/sounds/bangAlienShip.wav");
		bangLarge = createClip("/sounds/bangLarge.wav");
		bangMedium = createClip("/sounds/bangMedium.wav");
		bangShip = createClip("/sounds/bangShip.wav");
		bangSmall = createClip("/sounds/bangSmall.wav");
		fire = createClip("/sounds/fire.wav");
		saucerBig = createClip("/sounds/saucerBig.wav");
		saucerSmall = createClip("/sounds/saucerSmall.wav");
		thrust = createClip("/sounds/thrust.wav");

	}

	/**
	 * Returns the ship, or null if there isn't one
	 */
	public Ship getShip() {
		return ship;
	}

	/**
	 * Configures the game screen to display the splash screen
	 */

	private void splashScreen() {
		// Clear the screen, reset the level, and display the legend
		clear();
		level = 1;
		display.setLegend("Asteroids");

		// Place four asteroids near the corners of the screen.
		placeAsteroids();
	}

	/**
	 * The game is over. Displays a message to that effect.
	 */
	private void finalScreen() {
		display.setLegend(GAME_OVER);
		display.removeKeyListener(this);
	}

	/**
	 * Place a new ship in the center of the screen. Remove any existing ship
	 * first.
	 */
	private void placeShip() {
		// Place a new ship
		Participant.expire(ship);
		ship = new Ship(SIZE / 2, SIZE / 2, -Math.PI / 2, this);
		addParticipant(ship);
		display.setLegend("");

	}

	/**
	 * Places four asteroids near the corners of the screen. Gives them random
	 * velocities and rotations.
	 */
	private void placeAsteroids() {
		addParticipant(new Asteroid(0, 2, EDGE_OFFSET, EDGE_OFFSET, this));
//		addParticipant(new Asteroid(1, 2, SIZE - EDGE_OFFSET, EDGE_OFFSET, this));
//		addParticipant(new Asteroid(2, 2, EDGE_OFFSET, SIZE - EDGE_OFFSET, this));
//		addParticipant(new Asteroid(3, 2, SIZE - EDGE_OFFSET, SIZE - EDGE_OFFSET, this));
		/**
		 * This method make asteroids related to level, and the shape is random
		 * 
		 */
		for (int i = 1; i < level; i++) {
			addParticipant(new Asteroid(RANDOM.nextInt(3), 2, EDGE_OFFSET + i * 150,
					(SIZE - EDGE_OFFSET) + i * 100 * RANDOM.nextDouble(), this));
		}
	}

	/**
	 * Places the alien from left side. Gives the Y random
	 * 
	 */
	public void placeAlienShip() {
		if (pstate.countAlienShip() == 0) {
			// when level is 2, only bigger alien ship appears.
			if (level == 2) {
				AlienShip alienShip = new AlienShip(0, 0, 200 + ((double) Math.random() * 400), this);
				// sound
				if (saucerSmall.isRunning()) {
					saucerSmall.stop();
				}
				saucerSmall.setFramePosition(0);
				saucerSmall.loop(10);

				// Big alien ship comes out
				if (saucerBig.isRunning()) {
					saucerBig.stop();
				}
				saucerBig.setFramePosition(0);
				saucerBig.loop(10);
				new ParticipantCountdownTimer(alienShip, "addToScreen", 5000 + (5000 * (int) Math.random()));
			}
			// when the level is greater or equal 3, there are 50% small alien
			// ship appears
			if (level >= 3) {
				pickAlienShip = RANDOM.nextBoolean();
				if (pickAlienShip == true) {
					AlienShip alienShip = new AlienShip(1, 0, 200 + ((double) Math.random() * 400), this);
					// sound
					if (saucerSmall.isRunning()) {
						saucerSmall.stop();
					}
					saucerSmall.setFramePosition(0);
					saucerSmall.loop(10);

					// Big alineship coms out
					if (saucerBig.isRunning()) {
						saucerBig.stop();
					}
					saucerBig.setFramePosition(0);
					saucerBig.loop(10);
					new ParticipantCountdownTimer(alienShip, "addToScreen", 5000 + (5000 * (int) Math.random()));
				}
				// This method make small alien ship and big alien ship have 50%
				// appears each.
				if (pickAlienShip == false) {
					AlienShip alienShip = new AlienShip(0, 0, 200 + ((double) Math.random() * 400), this);
					if (saucerSmall.isRunning()) {
						saucerSmall.stop();
					}
					saucerSmall.setFramePosition(0);
					saucerSmall.loop(10);

					// Big alineship coms out
					if (saucerBig.isRunning()) {
						saucerBig.stop();
					}
					saucerBig.setFramePosition(0);
					saucerBig.loop(10);
					new ParticipantCountdownTimer(alienShip, "addToScreen", 5000 + (5000 * (int) Math.random()));
				}
			}
		}
	}

	// clear board
	private void clear() {
		pstate.clear();
		display.setLegend("");
		ship = null;
	}

	/**
	 * Sets things up and begins a new game.
	 */
	private void initialScreen() {
		// Clear the screen
		clear();

		// Place four asteroids
		placeAsteroids();

		// Place the ship
		placeShip();
		// fireBullet();

		// Reset statistics
		lives = 3;
		score = 0;
		level = 1;
		display.setLives(lives);
		display.setScores(score);
		display.setLevel(level);

		// Start listening to events
		display.removeKeyListener(this);
		display.addKeyListener(this);

		// Give focus to the game screen
		display.requestFocusInWindow();
	}

	// This method controls the limit of bullet which is 8, and controls the
	// ship to fire bullets
	private void fireBullet() {
		if (pstate.countBullets() < BULLET_LIMIT && ship != null && !ship.isExpired()) {
			Bullet bullet = new Bullet(ship.getXNose(), ship.getYNose(), ship.getRotation(), this);
			addParticipant(bullet);
		}
	}

	/**
	 * When level +, places asteroids, ship, and alien ship.
	 * 
	 */
	private void screen() {
		clear();
		level += 1;
		placeAsteroids();
		placeShip();
		display.setLevel(level);
		if (level >= 2) {
			placeAlienShip();
		}
	}

	/**
	 * Adds a new Participant
	 */
	public void addParticipant(Participant p) {
		pstate.addParticipant(p);
	}

	/**
	 * The ship has been destroyed
	 */

	public void shipDestroyed() {
		// Null out the ship
		if (bangShip.isRunning()) {
			bangShip.stop();
		}
		bangShip.setFramePosition(0);
		bangShip.start();
		lives -= 1;
		display.setLives(lives);
		// Display a legend
		display.setLegend("Ouch!");

		// Decrement lives

		// Since the ship was destroyed, schedule a transition
		scheduleTransition(END_DELAY);
	}

	/**
	 * 
	 * An asteroid of the given size has been destroyed
	 */
	public void asteroidDestroyed(int size) {
		addToScore(ASTEROID_SCORE[size]);

		// If all the asteroids are gone, schedule a transition
		if (pstate.countAsteroids() == 0) {

			scheduleTransition(END_DELAY);
		}
		// Sound
		if (bangSmall.isRunning()) {
			bangSmall.stop();
		}
		bangSmall.setFramePosition(0);
		bangSmall.start();

		if (bangMedium.isRunning()) {
			bangMedium.stop();
		}
		bangMedium.setFramePosition(0);
		bangMedium.start();

		if (bangLarge.isRunning()) {
			bangLarge.stop();
		}
		bangLarge.setFramePosition(0);
		bangLarge.start();
	}

	// The effect when alien ship destroyed, and add the score to screen
	public void AlienShipDestroyed(int size) {

		addToScore(ALIENSHIP_SCORE[size]);
		if (pstate.countAsteroids() == 0 && pstate.countAlienShip() == 0) {
			scheduleTransition(END_DELAY);
		}
		// sound
		if (bangAlienShip.isRunning()) {
			bangAlienShip.stop();
		}
		bangAlienShip.setFramePosition(0);
		bangAlienShip.start();
	}

	/**
	 * Schedules a transition m msecs in the future
	 */
	private void scheduleTransition(int m) {
		transitionTime = System.currentTimeMillis() + m;
	}

	// add score
	public void addToScore(int s) {
		score += s;
		display.setScores(score);
	}

	// level increases
	public int getLevel() {
		return level;
	}

	/**
	 * This method will be invoked because of button presses and timer events.
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		// The start button has been pressed. Stop whatever we're doing
		// and bring up the initial screen
		if (e.getSource() instanceof JButton) {
			initialScreen();
		}

		// Time to refresh the screen and deal with keyboard input
		else if (e.getSource() == refreshTimer) {
			if (keyPressL == true && ship != null) {
				ship.turnLeft();
			}
			if (keyPressR == true && ship != null) {
				ship.turnRight();
			}
			if (keyPressS == true && ship != null) {
				ship.accelerate();
				ship.setFireShape();

			}

			// It may be time to make a game transition
			performTransition();

			// Move the participants to their new locations
			pstate.moveParticipants();

			// Refresh screen
			display.refresh();
		}
	}

	/**
	 * Returns an iterator over the active participants
	 */
	public Iterator<Participant> getParticipants() {
		return pstate.getParticipants();
	}

	/**
	 * If the transition time has been reached, transition to a new state
	 */
	private void performTransition() {
		// Do something only if the time has been reached
		if (transitionTime <= System.currentTimeMillis()) {
			// Clear the transition time
			transitionTime = Long.MAX_VALUE;

			// If there are no lives left, the game is over. Show the final
			// screen.
			if (lives <= 0) {
				finalScreen();
			} else if (pstate.countAsteroids() == 0) {
				screen();
			}
			// If the ship was destroyed, place a new one and continue
			else if (ship == null || ship.isExpired()) {
				placeShip();
			}
		}
	}

	/*
	 * }
	 */
	/**
	 * If a key of interest is pressed, record that it is down.
	 */
	@Override
	public void keyPressed(KeyEvent e) {
		if (e.getKeyCode() == KeyEvent.VK_LEFT && ship != null) {
			keyPressL = true;

		} else if (e.getKeyCode() == KeyEvent.VK_A && ship != null) {
			keyPressL = true;

		}

		else if (e.getKeyCode() == KeyEvent.VK_RIGHT && ship != null) {
			keyPressR = true;
		} else if (e.getKeyCode() == KeyEvent.VK_D && ship != null) {
			keyPressR = true;
		} else if (e.getKeyCode() == KeyEvent.VK_W && ship != null) {
			keyPressS = true;
		}

		else if (e.getKeyCode() == KeyEvent.VK_UP && ship != null) {
			keyPressS = true;
		} else if (e.getKeyCode() == KeyEvent.VK_DOWN && ship != null && !ship.isExpired()) {

			fireBullet();
		} else if (e.getKeyCode() == KeyEvent.VK_SPACE && ship != null && !ship.isExpired()) {
			fireBullet();
			if (fire.isRunning()) {
				fire.stop();
			}
			fire.setFramePosition(0);
			fire.start();
		} else if (e.getKeyCode() == KeyEvent.VK_S && ship != null) {
			fireBullet();
			if (fire.isRunning()) {
				fire.stop();
			}
			fire.setFramePosition(0);
			fire.start();
		}
	}

	/**
	 * If a key of interest is pressed, record that it is down.
	 */
	@Override
	public void keyReleased(KeyEvent e) {
		if (e.getKeyCode() == KeyEvent.VK_LEFT && ship != null) {
			keyPressL = false;
			ship.setNormalShape();
		}
		if (e.getKeyCode() == KeyEvent.VK_RIGHT && ship != null) {
			keyPressR = false;
			ship.setNormalShape();
		}
		if (e.getKeyCode() == KeyEvent.VK_UP && ship != null) {
			keyPressS = false;
			ship.setNormalShape();
			if (thrust.isRunning()) {
				thrust.stop();
			}
			thrust.setFramePosition(0);
			thrust.start();
		}
		if (e.getKeyCode() == KeyEvent.VK_W && ship != null) {
			keyPressS = false;
			ship.setNormalShape();
			if (thrust.isRunning()) {
				thrust.stop();
			}
			thrust.setFramePosition(0);
			thrust.start();
		}
		if (e.getKeyCode() == KeyEvent.VK_A && ship != null) {
			keyPressL = false;
			ship.setNormalShape();
		}
		if (e.getKeyCode() == KeyEvent.VK_D && ship != null) {
			keyPressR = false;
			ship.setNormalShape();
		}
	}

	/**
	 * Ignore these events.
	 */
	@Override
	public void keyTyped(KeyEvent e) {
	}

	/**
	 * Creates an audio clip from a sound file.
	 */
	public Clip createClip(String soundFile) {
		// Opening the sound file this way will work no matter how the
		// project is exported. The only restriction is that the
		// sound files must be stored in a package.
		try (BufferedInputStream sound = new BufferedInputStream(getClass().getResourceAsStream(soundFile))) {
			// Create and return a Clip that will play a sound file. There are
			// various reasons that the creation attempt could fail. If it
			// fails, return null.-+

			Clip clip = AudioSystem.getClip();
			clip.open(AudioSystem.getAudioInputStream(sound));
			return clip;
		} catch (LineUnavailableException e) {
			return null;
		} catch (IOException e) {
			return null;
		} catch (UnsupportedAudioFileException e) {
			return null;
		}
	}
}
