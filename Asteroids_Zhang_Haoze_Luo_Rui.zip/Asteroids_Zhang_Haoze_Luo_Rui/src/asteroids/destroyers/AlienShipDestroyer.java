package asteroids.destroyers;

public abstract interface AlienShipDestroyer {}