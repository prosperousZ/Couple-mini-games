package asteroids.participants;

import java.awt.Shape;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.geom.*;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;

import asteroids.Controller;
import asteroids.Participant;
import asteroids.ParticipantCountdownTimer;
import asteroids.destroyers.*;
import static asteroids.Constants.*;

/**
 * Represents ships
 */
public class Ship extends Participant implements AsteroidDestroyer, KeyListener, AlienShipDestroyer {
	private Ship ship;

	// The outline of the ship
	private Shape outline;

	// Game controller
	private Controller controller;

	// Constructs a ship at the specified coordinates
	// that is pointed in the given direction.
	public Ship(int x, int y, double direction, Controller controller) {
		this.controller = controller;
		setPosition(x, y);
		setRotation(direction);

		setNormalShape();

		// Schedule an acceleration in two seconds
		// new ParticipantCountdownTimer(this, "move", 2000);
	}

	// The normal shape of the ship
	public void setNormalShape() {
		Path2D.Double poly = new Path2D.Double();
		poly.moveTo(20, 0);
		poly.lineTo(-20, 12);
		poly.lineTo(-13, 10);
		poly.lineTo(-13, -10);
		poly.lineTo(-20, -12);
		poly.closePath();
		outline = poly;
	}

	// The fire shape of the ship
	public void setFireShape() {
		Path2D.Double poly = new Path2D.Double();
		poly = new Path2D.Double();
		poly.moveTo(20.0D, 0.0D);
		poly.lineTo(-20.0D, 12.0D);
		poly.lineTo(-13.0D, 10.0D);
		poly.lineTo(-13.0D, -5.0D);
		poly.lineTo(-25.0D, 0.0D);
		poly.lineTo(-13.0D, 5.0D);
		poly.lineTo(-13.0D, -10.0D);
		poly.lineTo(-20.0D, -12.0D);
		poly.closePath();
		outline = poly;
	}

	// The shape when the ship expire
	public void setDieShape() {
		Path2D.Double poly = new Path2D.Double();
		poly.lineTo(-20, -12);
		poly.closePath();
		outline = poly;
	}

	/**
	 * Returns the x-coordinate of the point on the screen where the ship's nose
	 * is located.
	 */
	public double getXNose() {
		Point2D.Double point = new Point2D.Double(20, 0);
		transformPoint(point);
		return point.getX();
	}

	/**
	 * Returns the x-coordinate of the point on the screen where the ship's nose
	 * is located.
	 */
	public double getYNose() {
		Point2D.Double point = new Point2D.Double(20, 0);
		transformPoint(point);
		return point.getY();
	}

	// Get outline
	@Override
	protected Shape getOutline() {
		return outline;
	}

	/**
	 * Customizes the base move method by imposing friction
	 */
	@Override
	public void move() {
		applyFriction(SHIP_FRICTION);
		super.move();
	}

	/**
	 * Turns right by Pi/16 radians
	 */
	public void turnRight() {
		rotate(Math.PI / 24);
	}

	/**
	 * Turns left by Pi/16 radians
	 */
	public void turnLeft() {
		rotate(-Math.PI / 24);
	}

	/**
	 * Accelerates by SHIP_ACCELERATION
	 */
	public void accelerate() {
		accelerate(SHIP_ACCELERATION);
	}

	/**
	 * When a Ship collides with a ShipKiller, it expires
	 */
	@Override
	public void collidedWith(Participant p) {
		if (p instanceof ShipDestroyer) {
			// Expire the ship from the game
			Participant.expire(this);

			// Tell the controller the ship was destroyed
			controller.shipDestroyed();
			for (int i = 0; i < RANDOM.nextInt(3); i++) {
				controller.addParticipant(new shipDebris(getX(), getY(), controller));
			}
		}
	}

	/**
	 * This method is invoked when a ParticipantCountdownTimer completes its
	 * countdown.
	 */

	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub

	}
}
