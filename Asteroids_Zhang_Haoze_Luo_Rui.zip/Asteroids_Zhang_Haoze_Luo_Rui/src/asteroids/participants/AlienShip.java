package asteroids.participants;

import static asteroids.Constants.ALIENSHIP_SCALE;
import static asteroids.Constants.ALIENSHIP_SPEED;
import static asteroids.Constants.BULLET_DURATION;
import static asteroids.Constants.RANDOM;

import java.awt.Shape;
import java.awt.geom.AffineTransform;
import java.awt.geom.Path2D;
import java.awt.geom.Point2D;
import java.util.Date;

import asteroids.Controller;
import asteroids.Participant;
import asteroids.ParticipantCountdownTimer;
import asteroids.destroyers.AlienShipDestroyer;
import asteroids.destroyers.AsteroidDestroyer;
import asteroids.destroyers.ShipDestroyer;

public class AlienShip extends Participant implements ShipDestroyer, AsteroidDestroyer {
	// The size of the alien ship (0 = small, 1 = medium)
	private int size;
	private Ship ship;
	// The outline of the alien ship
	private Shape outline;
	// Time
	private long beginTime;
	// The game controller
	private Controller controller;
	// Initial Direction
	private double initialDirection = 0.0D;
	private boolean smallShip;

	/**
	 * Throws an IllegalArgumentException if size or variety is out of range.
	 * 
	 * Creates an alien ship of the specified variety (0 through 3) and size (0
	 * = small, 1 = medium) and positions it at the provided coordinates with a
	 * random rotation. Its velocity has the given speed but is in a random
	 * direction.
	 */
	public AlienShip(int size, double x, double y, Controller controller) {
		// Make sure size and variety are valid
		if (size < 0 || size > 1) {
			throw new IllegalArgumentException("Invalid alien ship size: " + size);
		}
		// Create the alien ship
		this.controller = controller;
		this.size = size;
		// Different size of alien ship will have different speed
		double speed = ALIENSHIP_SPEED[size];
		// Initial direction
		if (RANDOM.nextBoolean()) {
			initialDirection = Math.PI;
		}
		setPosition(x, y);
		// setVelocity(speed, RANDOM.nextDouble() * 2 * Math.PI);
		setVelocity(speed, initialDirection);
		setRotation(0);
		createAlienShipOutline(size);
	}

	/**
	 * Get outline
	 */
	@Override
	protected Shape getOutline() {
		return createAlienShipOutline(size);
	}

	/**
	 * Creates the outline of the asteroid based on its variety and size.
	 */
	private Shape createAlienShipOutline(int size) {
		if (size == 0) {
			Path2D.Double poly = new Path2D.Double();
			poly.moveTo(41, 1);
			poly.lineTo(19, 19);
			poly.lineTo(-17, 19);
			poly.lineTo(-39, 1);
			poly.lineTo(41, 1);
			poly.lineTo(-39, 1);
			poly.lineTo(-17, -17);
			poly.lineTo(19, -17);
			poly.lineTo(-17, -17);
			poly.lineTo(-9, -33);
			poly.lineTo(12, -33);
			poly.lineTo(19, -17);
			poly.closePath();
			// Scale to the desired size
			double scale = ALIENSHIP_SCALE[0];
			poly.transform(AffineTransform.getScaleInstance(scale, scale));
			beginTime = (new Date()).getTime();
			// Save the outline
			outline = poly;
		}
		if (size == 1) {
			Path2D.Double poly = new Path2D.Double();
			poly.moveTo(20.5, 0.5);
			poly.lineTo(9.5, 9.5);
			poly.lineTo(-8.5, 9.5);
			poly.lineTo(-19.5, 0.5);
			poly.lineTo(20.5, 0.5);
			poly.lineTo(-19.5, 0.5);
			poly.lineTo(-8.5, -8.5);
			poly.lineTo(9.5, -8.5);
			poly.lineTo(-8.5, -8.5);
			poly.lineTo(-4.5, -16.5);
			poly.lineTo(6, -16.5);
			poly.lineTo(9.5, -8.5);
			poly.closePath();
			// Scale to the desired size
			double scale = ALIENSHIP_SCALE[0];
			poly.transform(AffineTransform.getScaleInstance(scale, scale));
			beginTime = (new Date()).getTime();
			// Save the outline
			outline = poly;
		}
		return outline;
	}

	/**
	 * Returns the size of the alien ship
	 */
	public int getSize() {
		return size;
	}

	/**
	 * when at level >= 2, computer calls the timer called "addToScreen", will
	 * add an alien ship after 5 second after it was destroyed, and creat
	 * another timers shoot and move
	 */
	@Override
	public void countdownComplete(Object payload) {

		if (payload.equals("move")) {
			// change the direction
			changePath();
			new ParticipantCountdownTimer(this, "move", 1000);
		}

		if (payload.equals("addToScreen")) {

			controller.addParticipant(this);
			new ParticipantCountdownTimer(this, "move", 1000);
			new ParticipantCountdownTimer(this, "shoot", 2000);

		}
		if (payload.equals("shoot")) {
			if (this.getSize() == 0) {
				AlienFireBullet();
				new ParticipantCountdownTimer(this, "shoot", 2000);
			}
			if (this.getSize() == 1) {
				smallAlienShipFireBullet();
				new ParticipantCountdownTimer(this, "shoot", 2000);
			}
		}
	}

	// Z Path
	public void changePath() {
		setDirection(initialDirection + (RANDOM.nextInt(3) - 1.0D));
	}

	// The bigger alien ship fire random bullet
	public void AlienFireBullet() {
		AlienShipBullet bullet = new AlienShipBullet((getX()), getY(),
				(-Math.PI / 2) + RANDOM.nextDouble() * (Math.PI));
		this.controller.addParticipant(bullet);
	}

	// The smaller alien ship fire bullet to Ship
	public void smallAlienShipFireBullet() {
		AlienShipBullet b = new AlienShipBullet(getX(), getY(), getShootingDirection());
		b.setSpeed(13.0D);
		this.controller.addParticipant(b);
	}

	// Shooting direction
	public double getShootingDirection() {
		Ship ship = this.controller.getShip();
		double X = ship.getX() - getX();
		double Y = ship.getY() - getY();
		double d = Math.sqrt(X * X + Y * Y);
		double direction = Math.acos(X / d);
		return Y > 0.0D ? direction : -direction;
	}
	// public void alienFired() {
	// if (ship != null) {
	// if (alien.getSize() == 1) {
	// double radian = Math.atan((ship.getY() - alien.getY()) / (ship.getX() -
	// alien.getX()));
	// if (ship.getX() < alien.getX()) {
	// radian += Math.PI;
	// addParticipant(new AlienBullet(alien.getX(), alien.getY(), radian,
	// this));
	// }
	// }else{
	// addParticipant(new AlienBullet(alien.getX(), alien.getY(), 2 *
	// RANDOM.nextDouble() * Math.PI, this));
	// }
	// }
	// }

	public double getXNose() {
		Point2D.Double point = new Point2D.Double(20, 0);
		transformPoint(point);
		return point.getX();
	}

	public double getYNose() {
		Point2D.Double point = new Point2D.Double(20, 0);
		transformPoint(point);
		return point.getY();
	}

	/**
	 * When an alien ship collides with an AlienDestroyer, it expires.
	 */
	@Override
	public void collidedWith(Participant p) {

		if (p instanceof AlienShipDestroyer) {
			// Expire the asteroid
			Participant.expire(this);
			controller.AlienShipDestroyed(getSize());
			int size = getSize() - 1;

			for (int i = 0; i < RANDOM.nextInt(4); i++) {
				controller.addParticipant(new Debris(getX(), getY(), controller));
			}
		}
		if (this == null || this.isExpired()) {

			controller.placeAlienShip();
		}

	}

}