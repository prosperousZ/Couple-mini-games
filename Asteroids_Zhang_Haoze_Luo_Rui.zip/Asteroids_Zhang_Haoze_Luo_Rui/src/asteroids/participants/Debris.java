package asteroids.participants;

import static asteroids.Constants.*;
import java.awt.Shape;
import java.awt.geom.Path2D;
import java.util.*;
import asteroids.Controller;
import asteroids.Participant;
import asteroids.ParticipantCountdownTimer;

public class Debris extends Participant

{
	private Shape outline;
	private Controller controller;
	private long beginTime;

	/**
	 * Outline of the debris
	 */
	public Debris(double x, double y, Controller controller) {
		this.controller = controller;
		setPosition(x, y);
		setVelocity(DEBRIS_SPEED, RANDOM.nextDouble() * 2 * Math.PI);
		setRotation(2 * Math.PI * RANDOM.nextDouble());
		Path2D.Double poly = new Path2D.Double();
		poly.moveTo(20, 0);
		poly.lineTo(22, 2);
		poly.closePath();
		outline = poly;
		beginTime = (new Date()).getTime();
		new ParticipantCountdownTimer(this, "move", 200);
	}

	/**
	 * This method is invoked when a ParticipantCountdownTimer completes its
	 * countdown.
	 */
	@Override
	public void countdownComplete(Object payload) {

		if (((new Date()).getTime() - beginTime) > DEBRIS_DURATION) {
			Participant.expire(this);
		} else {
			new ParticipantCountdownTimer(this, "move", 200);
		}
	}

	// Get outline
	@Override
	protected Shape getOutline() {

		return this.outline;
	}

	@Override
	public void collidedWith(Participant p) {

	}

}
