package asteroids.participants;

import static asteroids.Constants.*;

import java.awt.Shape;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.geom.Path2D;
import java.util.*;

import asteroids.Controller;
import asteroids.Participant;
import asteroids.ParticipantCountdownTimer;
import asteroids.destroyers.AsteroidDestroyer;
import asteroids.destroyers.ShipDestroyer;

public class AlienShipBullet extends Participant implements AsteroidDestroyer, ShipDestroyer {
	private Ship ship;
	// Get outline
	private Shape outline;
	private Controller controller;
	private long beginTime;

	/**
	 * Creat the alien ship bullet outline
	 */
	public AlienShipBullet(double x, double y, double direction) {
		setPosition(x, y);
		setRotation(direction);
		setVelocity(BULLET_SPEED, direction);
		Path2D.Double poly = new Path2D.Double();
		poly.moveTo(-1, 0);
		poly.lineTo(1, 0);
		poly.lineTo(0, 1);
		poly.closePath();
		outline = poly;
		beginTime = (new Date()).getTime();
		new ParticipantCountdownTimer(this, "alienFire", 200);
	}

	/**
	 * This method is invoked when a ParticipantCountdownTimer completes its
	 * countdown.
	 */
	@Override
	public void countdownComplete(Object payload) {

		if (((new Date()).getTime() - beginTime) > ShipBULLET_DURATION) {
			Participant.expire(this);
		} else {
			new ParticipantCountdownTimer(this, "alienFire", 200);
		}
	}

	@Override
	protected Shape getOutline() {

		return this.outline;
	}

	// expire when hit other stuff
	@Override
	public void collidedWith(Participant p) {
		if (p instanceof Asteroid || p instanceof Ship) {
			Participant.expire(this);
			Participant.expire(p);
		}
	}

}