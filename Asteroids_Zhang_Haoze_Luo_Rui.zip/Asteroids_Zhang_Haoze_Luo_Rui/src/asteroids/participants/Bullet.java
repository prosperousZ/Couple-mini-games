package asteroids.participants;

import static asteroids.Constants.*;

import java.awt.Shape;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.geom.Path2D;
import java.util.*;

import asteroids.Controller;
import asteroids.Participant;
import asteroids.ParticipantCountdownTimer;
import asteroids.destroyers.AlienShipDestroyer;
import asteroids.destroyers.AsteroidDestroyer;

public class Bullet extends Participant implements AsteroidDestroyer, AlienShipDestroyer

{
	private Ship ship;
	private Shape outline;
	private Controller controller;
	private long beginTime;

	// Outline of ship bullet
	public Bullet(double x, double y, double direction, Controller controller) {
		this.controller = controller;
		setPosition(x, y);
		setRotation(direction);
		setVelocity(BULLET_SPEED, direction);
		Path2D.Double poly = new Path2D.Double();
		poly.moveTo(-1, 0);
		poly.lineTo(1, 0);
		poly.lineTo(0, 1);

		poly.closePath();
		outline = poly;
		beginTime = (new Date()).getTime();
		new ParticipantCountdownTimer(this, "fire", 200);
	}

	/**
	 * This method is invoked when a ParticipantCountdownTimer completes its
	 * countdown.
	 */
	@Override
	public void countdownComplete(Object payload) {

		if (((new Date()).getTime() - beginTime) > BULLET_DURATION) {
			Participant.expire(this);
		} else {
			new ParticipantCountdownTimer(this, "fire", 200);
		}
	}

	// Get outline
	@Override
	protected Shape getOutline() {

		return this.outline;
	}

	// expire other stuff
	@Override
	public void collidedWith(Participant p) {
		if (p instanceof Asteroid || p instanceof AlienShip) {
			Participant.expire(this);
			Participant.expire(p);
		}
	}

}
