package asteroids;

import javax.swing.*;

import java.awt.*;

import static asteroids.Constants.*;

/**
 * Defines the top-level appearance of an Asteroids game.
 */
@SuppressWarnings("serial")
public class Display extends JFrame {
	// The area where the action takes place
	private Screen screen;
	private JLabel Scores;
	private JLabel Lives;
	private JLabel Levels;

	/**
	 * Lays out the game and creates the controller
	 */
	public Display(Controller controller) {

		setTitle(TITLE);

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		// The main playing area and the controller
		screen = new Screen(controller);

		// This panel contains the screen to prevent the screen from being
		// resized
		JPanel screenPanel = new JPanel();
		screenPanel.setLayout(new GridBagLayout());
		screenPanel.add(screen);
		JPanel mainPanel = new JPanel();
		mainPanel.setLayout(new BorderLayout());
		mainPanel.add(screenPanel, "Center");
		JPanel p = new JPanel();
		mainPanel.add(p, "North");
		setContentPane(mainPanel);
		pack();
		p.setLayout(new GridLayout(1, 2));

		JPanel top = new JPanel();
		Scores = new JLabel();
		top.add(Scores);
		screenPanel.add(top);
		p.add(top);

		JPanel mid = new JPanel();
		p.add(mid);

		// mid.add(new JLabel("Lives:"));
		Lives = new JLabel();
		top.add(Lives);
		screenPanel.add(top);
		p.add(top);

		// bot.add(new JLabel("Level:"));
		Levels = new JLabel();
		top.add(Levels);
		screenPanel.add(top);
		p.add(top);

		JButton startGame = new JButton(START_LABEL);
		mid.add(startGame);
		startGame.addActionListener(controller);
		Levels = new JLabel();

		top.add(Levels);
		Lives = new JLabel();
		top.add(Lives);
		Scores = new JLabel();
		top.add(Scores);
	}

	/**
	 * Called when it is time to update the screen display. This is what drives
	 * the animation.
	 */
	public void refresh() {
		screen.repaint();
	}

	public void setLevel(int n) {
		Levels.setText("levels:" + n);
	}

	public void setLives(int n) {
		Lives.setText("Lives" + n);
	}

	public void setScores(int n) {
		Scores.setText("Scores:" + n);
	}

	/**
	 * Sets the large legend
	 */
	public void setLegend(String s) {
		screen.setLegend(s);
	}
}
